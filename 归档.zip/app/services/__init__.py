"""
服务模块
"""
from app.services.tts_service import TTSService

__all__ = ["TTSService"]

