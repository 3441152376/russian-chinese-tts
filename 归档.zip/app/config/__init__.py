"""
配置模块
"""
from app.config.settings import settings

__all__ = ["settings"]

