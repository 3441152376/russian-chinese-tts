"""
控制器模块
"""
from app.controllers.tts_controller import router as tts_router

__all__ = ["tts_router"]

