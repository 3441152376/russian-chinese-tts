"""
Edge TTS 后端服务
提供文本转语音功能的 RESTful API 服务
"""

__version__ = "1.0.0"

